class Ciudad {
  late String nombre;
  late String descrpcion;
  late String foto;

  Ciudad(this.nombre, this.descrpcion, this.foto);
  String getNombre() {
    return nombre;
  }
}
